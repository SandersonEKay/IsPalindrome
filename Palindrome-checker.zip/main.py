#bit bot practice

#print("welcome to Bianary Bit Bot!")
#Bit_Number = input("How many Bits? enter a number between 1 and 8:")
#for i in Bit_Number:
  #print(str(2**int(Bit_Number)))

#write a palindrome checker 
#Possible_pali = input("Enter a word to check if its a palindrome:")
#if Possible_pali[1] = Possible_pali[]

#answer for 1

#define function
#def print_exponent(a,b):
  #print(a**b)

#get imput from the user
#print("welcome to Bianary Bit Bot!")
#Bit_Number = int(input("How many Bits? enter a number between 1 and 8:"))

#output 2**x on each line 
#for i in range(Bit_Number):
 # print_exponent(2, x)
 
#make a boolean variable to store weather it is a palindrome or Not
is_pali = False

#get imput
word = input("Enter a word to check if it is a pali:")
#get length of word
length = len(word)

#check if it is a plai to update the variable
for i in range(length):
  if word[i] == word[length -1]:
    is_pali = True
  else:
    is_pali = False
    
if is_pali:
  print("thats a palindrome")
else:
  print("thats not a palindrome")
 
 
 
 
 
 
 
 