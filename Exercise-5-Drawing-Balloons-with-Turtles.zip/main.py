# Exercise 5 - Drawing Balloons with Turtles and while loop
# Author jennifer lao
# Date: 21-Feb-2018
# Description: A program to draw balloons using turtle graphics
#           This program prompts the user for the number of ballons to draw and their colour.
#           It loops until the user enters N to leave the program.
##############################################################################################
#Technical requirements:
#                       Use Turtle Graphics,
#                       Use a while loop
#                       Use at least one function.
#
##############################################################################################
# Import turtle module

import turtle

# Define The colors

RED =   "#FF0000"
ORANGE = "#FFA500"
YELLOW = "#FFFF00"
GREEN = "#00FF00"
BLUE  = "#0000FF"
INDIGO = "#480082"
BROWN = "#A52A2A"

##############################################################################################
# A function to draw a balloon using turtle graphics
#
def myBalloon(t,x,y,radius):
    """ Function myBalloon.  Draw a balloon of the specified shape and location. 
        myBaloon(Turtle, horizontal co-ordinate, vertical co-ordinate, radius) """
        
    original_pensize = t.pensize()      # Preserve the pensize
    t.pensize(original_pensize * 3) # Triple the size for the string
    t.penup()                           # Stop Drawing
    t.goto(x,y)                         # Positon the cursor
    t.pendown()                         # Get ready to draw
    t.begin_fill()                    # Get ready to color the balloon
    t.circle(radius)                    # Draw
    t.end_fill()                        # Color the balloon
    t.penup()                           # Stop Drawing
    t.right(90)                         # Turn downwards
    t.pendown()                         # Ready to draw
    t.forward(radius*2)    # Draw a string downward at twice the radius
    t.penup()                           # Stop Drawing
    t.home()                            # Reset the position
    t.pensize(original_pensize)         # Restore the pensize.

# Main Procedure
# Create the turtle, hide the cursor and set the speed to fastest.

t1 = turtle.Turtle()
t1.hideturtle()
t1.speed(0)

while True:                             # Main loop

    
    # See if they want to draw some balloons
    
    command = input("\n\nWould you like to draw some baloons ? [N to exit] ")
    if command.lower()  == "n":
        break                           # We're done
    
    # Get the number of balloons to draw and the color.
    
   
    while True:
        response = input("\nHow many baloons would you like ? [ 1 to 50] ")
        try:    
            number = int(response)    # Try and see if we can convert 
                               # the string we received into a integer
            if number > 0 and number <= 50 :    # Check it's in range
                break               # It's valid break out of the loop
        except ValueError:            # Guess it's not a valid number
            print("That's not a valid number. Please try again") 
                                          # Tell the user to try again
    # End while
    
    while True:
        response = input("What color would you like?  [ 1 = Red, 2 = Green, 3 = Orange, 4 = Blue, 5 = Yellow 6 = Brown] ")
        try:    
            color = int(response)       # Try and see if we can convert 
                                # the string we received into a integer
            if color > 0 and color <= 6 :       # Range check it
                break               # It's valid break out of the loop
        except ValueError:          # Guess it's not a valid number
            print("That's not a valid number. Please try again") # Tell the user to try again       
    # End while
    
    
    t1.clear()                              # Clear the screen
    
    # Set the fillcolor,  default to blue.
    if color == 1:
        t1.fillcolor(RED)
    elif color == 2:
        t1.fillcolor(GREEN)
    elif color == 3:
        t1.fillcolor(ORANGE)
    elif color == 4:
        t1.fillcolor(BLUE)
    elif color == 5:
        t1.fillcolor(YELLOW)
    elif color == 6:
        t1.fillcolor(BROWN)
    
    
    # Figure out the geometry and placement of the balloons based on the number they entered.
    
    radius =  200 / number                  # Maximum is 200 pixels across
    right = (3 * radius * number / 2) - radius # Half the balloons are to the right of centre.
    left = -right                           # Start on the left.
    step = radius * 3                       # Spacing is same as the radius
    h1 = left
    for i in range(number):
        myBalloon(t1,h1,0,radius)           # Draw the balloon
        h1 = h1 + step                      # Step to the right.
        
    print("\nClick the 'result tab' to see your balloon's")
        
   